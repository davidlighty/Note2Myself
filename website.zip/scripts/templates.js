this["JST"] = this["JST"] || {};

this["JST"]["app/scripts/templates/addimagenote_modal.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<div class="bbm-modal__topbar">\r\n    <h3 class="bbm-modal__title">Save an image</h3>\r\n</div>\r\n<div class="bbm-modal__section">\r\n    <div class="alert alert-error" style="display:none;">\r\n    </div>\r\n    <form class="form-horizontal" id="image-form" enctype="multipart/form-data">\r\n        <section>\r\n            <input type="text" placeholder="Title" id="new-note-title"  autofocus/>\r\n        </section>\r\n        <section>\r\n            <input type="file" placeholder="What would you like to save?" name="newnoteimage" id="new-note-image"></textarea>\r\n        </section>\r\n    </form>\r\n</div>\r\n<div class="bbm-modal__bottombar">\r\n    <button type="submit" class="btn btn-primary" id="addButton" form="image-form">Add</button>\r\n    <a href="#" class="bbm-button">Close</a>\r\n</div>';

}
return __p
};

this["JST"]["app/scripts/templates/addnote_modal.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<div class="bbm-modal__topbar">\r\n    <h3 class="bbm-modal__title">Add your note</h3>\r\n</div>\r\n<div class="bbm-modal__section">\r\n    <div class="alert alert-error" style="display:none;">\r\n    </div>\r\n    <form class="form-horizontal" id="new-note-form">\r\n        <section>\r\n            <input type="text" placeholder="Title" id="new-note-title"  autofocus/>\r\n        </section>\r\n        <section>\r\n            <textarea type="text" placeholder="What would you like to save?" id="new-note-text"></textarea>\r\n        </section>\r\n    </form>\r\n</div>\r\n<div class="bbm-modal__bottombar">\r\n    <button type="submit" class="btn btn-primary" id="addButton" form="new-note-form">Add</button>\r\n    <a href="#/" class="bbm-button">Close</a>\r\n</div>';

}
return __p
};

this["JST"]["app/scripts/templates/addtodonote_modal.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<div class="bbm-modal__topbar">\r\n    <h3 class="bbm-modal__title">Need to make a list?</h3>\r\n</div>\r\n<div class="bbm-modal__section">\r\n    <div class="alert alert-error" style="display:none;">\r\n    </div>\r\n    <form class="form-horizontal" id="login-form">\r\n        <section>\r\n            <input type="text" placeholder="Title" id="new-note-title"  autofocus/>\r\n        </section>\r\n        <section>\r\n        <div class="input-group">\r\n            <input type="text" placeholder="What needs to be done?" id="new-note-todo" class="form-control" />\r\n            <span id="add-todo-item" class="input-group-addon"><i class="fa fa-plus fa-2"></i></span>\r\n        </div>\r\n        </section>\r\n        <div id="new-todo-list">            </div>\r\n    </form>\r\n</div>\r\n<div class="bbm-modal__bottombar">\r\n    <button type="submit" class="btn btn-primary" id="addButton" form="login-form" disabled>Add</button>\r\n    <a href="#" class="bbm-button">Close</a>\r\n</div>';

}
return __p
};

this["JST"]["app/scripts/templates/addwebnote_modal.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<div class="bbm-modal__topbar">\r\n    <h3 class="bbm-modal__title">Save Website Link</h3>\r\n</div>\r\n<div class="bbm-modal__section">\r\n    <div class="alert alert-error" style="display:none;">\r\n    </div>\r\n    <form class="form-horizontal" id="login-form">\r\n        <section>\r\n            <input type="text" placeholder="Website" id="new-note-title" autofocus/>\r\n        </section>\r\n        <section>\r\n            <textarea type="text" placeholder="What would you like to save?" id="new-note-text"></textarea>\r\n        </section>\r\n    </form>\r\n</div>\r\n<div class="bbm-modal__bottombar">\r\n<button type="submit" class="btn btn-primary" id="addButton" form="login-form" disabled>Add</button>\r\n    <a href="#" class="bbm-button">Close</a>\r\n</div>';

}
return __p
};

this["JST"]["app/scripts/templates/fullimage_modal.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<div class="bbm-modal__section fullimage">\r\n<a href="#" class="bbm-button">Close</a>\r\n    <div>\r\n        <img src="./api/image/' +
((__t = (imageId)) == null ? '' : __t) +
'" />\r\n    </div>\r\n</div>';

}
return __p
};

this["JST"]["app/scripts/templates/home.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<section>\r\n\t<h1>Home</h1>\r\n\t<section>\r\n\t\t<ul>\r\n\t\t\t<li>\r\n\t\t\t\t<div>\r\n\t\t\t\t\tmarketing1\r\n\t\t\t\t</div>\r\n\t\t\t\t<div>\r\n\t\t\t\t\tmarketing2\r\n\t\t\t\t</div>\r\n\t\t\t\t<div>\r\n\t\t\t\t\tmarketing3\r\n\t\t\t\t</div>\r\n\t\t\t</li>\r\n\t\t</ul>\r\n\t</section>\r\n</section>';

}
return __p
};

this["JST"]["app/scripts/templates/login.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<div class="bbm-modal__topbar">\r\n    <h3 class="bbm-modal__title">Welcome to NoteApp</h3>\r\n</div>\r\n<div class="bbm-modal__section">\r\n    <div class="alert alert-error" style="display:none;">\r\n    </div>\r\n    <ul>\r\n        <li>\r\n            <div>\r\n                <!-- login form -->\r\n                <form class="form-horizontal" id="login-form">\r\n                    <div class="control-group">\r\n                        <label class="control-label" for="inputEmail">Email</label>\r\n                        <div class="controls">\r\n                            <input type="email" id="inputEmail" placeholder="Email" class="form-control" required>\r\n                        </div>\r\n                    </div>\r\n                    <div class="control-group">\r\n                        <label class="control-label" for="inputPassword">Password</label>\r\n                        <div class="controls">\r\n                            <input type="text" id="inputPassword" placeholder="Password" class="form-control" required>\r\n                        </div>\r\n                    </div>\r\n                </form>\r\n            </div>\r\n        </li>\r\n    </ul>\r\n</div>\r\n<div class="bbm-modal__bottombar">\r\n    <button  id="forgotpassword" class="btn">Forgot your password?</button>\r\n    <button type="submit" class="btn" id="registerButton" form="login-form">Register</button>\r\n    <button type="submit" class="btn btn-primary" id="loginButton" form="login-form">Sign in</button>\r\n</div>';

}
return __p
};

this["JST"]["app/scripts/templates/nav.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<div class="navbar navbar-default navbar-fixed-top" role="navigation">\r\n      <div class="container">\r\n        <div class="navbar-header">\r\n          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">\r\n            <span class="sr-only">Toggle navigation</span>\r\n            <span class="icon-bar"></span>\r\n            <span class="icon-bar"></span>\r\n            <span class="icon-bar"></span>\r\n          </button>\r\n          <a class="navbar-brand" href="#">' +
((__t = ( notesApp.Title )) == null ? '' : __t) +
'</a>\r\n        </div>\r\n        <div class="navbar-collapse collapse">\r\n          <ul class="nav navbar-nav">\r\n           <li class="dropdown">\r\n              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Account <span class="caret"></span></a>\r\n              <ul class="dropdown-menu" role="menu">\r\n                <li><a href="#account"><i class="fa fa-cog"></i> Account</a></li>\r\n                <li><a href="#logout"><i class="fa fa-sign-out"></i> Logout</a></li>\r\n                              </ul>\r\n            </li>\r\n            <li class="dropdown">\r\n              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Add Note <span class="caret"></span></a>\r\n              <ul class="dropdown-menu" role="menu">\r\n                <li class="dropdown-header">Select type:</li>\r\n                <li><div class="note-text"><i class="fa fa-pencil-square-o"></i> Text</div></li>\r\n                <li><div class="note-web"><i class="fa fa-external-link"></i> Website</div></li>\r\n                <li><div class="note-todo"><i class="fa fa-list-ul"></i> Todos</div></li>\r\n                <li><div class="note-img"><i class="fa fa-picture-o"></i> Image</div></li>\r\n              </ul>\r\n            </li>\r\n          </ul>\r\n<!--           <ul class="nav navbar-nav navbar-right">\r\n            <li><a href="../navbar/">Default</a></li>\r\n            <li><a href="../navbar-static-top/">Static top</a></li>\r\n            <li class="active"><a href="./">Fixed top</a></li>\r\n          </ul> -->\r\n        </div><!--/.nav-collapse -->\r\n      </div>\r\n    </div>';

}
return __p
};

this["JST"]["app/scripts/templates/note.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<section class="note-section">\r\n    <div class="note-data">\r\n        \r\n    </div>\r\n    <section class="note-cmds">\r\n        <ul class="note-stats">\r\n            <li>\r\n<!--                 <div>\r\n                    <small>Note type: ' +
((__t = ( type )) == null ? '' : __t) +
'</small>\r\n                </div> -->\r\n            </li>\r\n        </ul>\r\n        <ul class="note-stats edit-note-cmds">\r\n            <li><span class="update-note"><i class="fa fa-floppy-o"></i></span></li>\r\n            <li><span class="edit-note"><i class="fa fa-pencil"></i></span></li>\r\n            <li><span class="edit-undo"><i class="fa fa-undo"></i></span></li>\r\n            <li><span class="delete-note"><i class="fa fa-times-circle"></i></span></li>\r\n        </ul>\r\n    </section>\r\n</section>';

}
return __p
};

this["JST"]["app/scripts/templates/notes.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<!-- <section class="quick-note-section">\r\n    <div class="quick-note-text" data-toggle="tooltip" data-placement="top" title="Add a quick note.  Just hit enter to add!">\r\n    \t<span class="note-add"><i class="fa fa-plus fa-2"></i></span>\r\n        <textarea type="text" placeholder="What would you like to save?" id="new-note-text"></textarea>\r\n    </div>\r\n</section> -->\r\n<section class="notes-section">\r\n    <div class="note-list-section">\r\n        <ul id="notes-list">\r\n        </ul>\r\n    </div>\r\n</section>';

}
return __p
};

this["JST"]["app/scripts/templates/notetype/image.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<!-- Image Template -->\r\n<div class="note-title-section">\r\n    <h1 class="note-title">' +
((__t = ( title )) == null ? '' : __t) +
'</h1>\r\n    <input type="text" value="' +
((__t = ( title )) == null ? '' : __t) +
'" class="note-title-edit" placeholder="Want a title? "/>\r\n</div>\r\n<div class="note-text-section">\r\n<div class="note-image">\r\n<img src="./api/image/' +
((__t = (imageId)) == null ? '' : __t) +
'" />\r\n</div>\r\n    <p class="note-text">\r\n    ' +
((__t = ( text )) == null ? '' : __t) +
'\r\n    </p>\r\n    <textarea type="text" placeholder="What would you like to save?" class="note-text-edit">' +
((__t = ( text )) == null ? '' : __t) +
'</textarea>\r\n</div>';

}
return __p
};

this["JST"]["app/scripts/templates/notetype/text.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<!-- Text Template -->\r\n<div class="note-title-section">\r\n    <h1 class="note-title">' +
((__t = ( title )) == null ? '' : __t) +
'</h1>\r\n    <input type="text" value="' +
((__t = ( title )) == null ? '' : __t) +
'" class="note-title-edit" placeholder="Want a title? "/>\r\n</div>\r\n<div class="note-text-section">\r\n    <p class="note-text">\r\n    ' +
((__t = ( text )) == null ? '' : __t) +
'\r\n    </p>\r\n    <textarea type="text" placeholder="What would you like to save?" class="note-text-edit">' +
((__t = ( text )) == null ? '' : __t) +
'</textarea>\r\n</div>';

}
return __p
};

this["JST"]["app/scripts/templates/notetype/todo.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<!-- Todo Template -->\r\n<div class="note-title-section">\r\n    <h1 class="note-title">' +
((__t = ( title )) == null ? '' : __t) +
'</h1>\r\n    <input type="text" value="' +
((__t = ( title )) == null ? '' : __t) +
'" class="note-title-edit" placeholder="Want a title? "/>\r\n</div>\r\n<div class="note-text-section">\r\n    <ul class="note-items">\r\n    </ul>\r\n</div>\r\n';

}
return __p
};

this["JST"]["app/scripts/templates/notetype/website.ejs"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<!-- Website Template -->\r\n<div class="note-title-section">\r\n\t<a href="' +
((__t = ( title )) == null ? '' : __t) +
'" target="blank"> <h1 class="note-title">' +
((__t = ( title )) == null ? '' : __t) +
'</h1></small></a>\r\n    <input type="text" value="' +
((__t = ( title )) == null ? '' : __t) +
'" class="note-title-edit" placeholder="Want a title? "/>\r\n</div>\r\n<div class="note-text-section">\r\n\t<p><small>Description: ' +
((__t = ( description )) == null ? '' : __t) +
'</small></p>\r\n    <p class="note-text">\r\n    ' +
((__t = ( text )) == null ? '' : __t) +
'\r\n    </p>\r\n    <textarea type="text" placeholder="What would you like to save?" class="note-text-edit">' +
((__t = ( text )) == null ? '' : __t) +
'</textarea>\r\n</div>';

}
return __p
};