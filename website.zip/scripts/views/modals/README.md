Note Modal Views
================

Modal views for each note type