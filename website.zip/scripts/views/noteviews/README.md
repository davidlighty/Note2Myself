Note Views
==========

Views for each Note Type