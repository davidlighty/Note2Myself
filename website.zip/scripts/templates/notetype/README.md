Note Types
==========

Templates for each Note Type that we are allowing

1. Text
2. Website
3. Todo