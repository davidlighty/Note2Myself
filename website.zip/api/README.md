Note2Myself
===========

Features:
- PHP API for Notes
- PHP API for Users
